export default {
  apiUrl: 'https://api.cai.tools.sap/connect/v1',
}
