import enTranslations from './en.json'
import jaTranslations from './ja.json'

export default {
  en: enTranslations,
  ja: jaTranslations,
}
